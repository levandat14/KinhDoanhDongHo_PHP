<?php

session_start();
require_once('../ketnoi/ketnoi.php');

?>
<?php

if(isset($_POST['submit'])){
    $tk=$_POST['tk'];
    $mk=$_POST['mk'];
	if(isset($tk) && isset($mk)){
	$sql="SELECT * FROM admin WHERE TenDangNhap='$tk' AND MatKhau='$mk' ";
	$query=mysqli_query($conn, $sql);
	$row=mysqli_num_rows($query);

	if($row>0){
		
		header('location: quantri.php');
	}
	else{
		echo "ngu";
	}
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8" />
	<title>Vietpro Mobile Shop - Đăng nhập hệ thống</title>
	<link rel="stylesheet" type="text/css" href="css/dangnhap.css" />
</head>
<body>
	<?php
		if(!isset($_SESSION['tk'])){


	?>
	<form method="post">
	<div id="form-login">
		<h2>đăng nhập hệ thống quản trị</h2>
	
	    <ul>
	        <li><label>tài khoản</label><input type="text" name="tk" /></li>
	        <li><label>mật khẩu</label><input type="password" name="mk" /></li>
	        <li><label>ghi nhớ</label><input type="checkbox" name="check" checked="checked" /></li>
	        <li><input type="submit" name="submit" value="Đăng nhập" /> <input type="reset" name="resset" value="Làm mới" /></li>
	    </ul>
	</div>
	</form>
	<?php
}else{
	header('location:quantri.php');
}

	?>
</body>
</html>
