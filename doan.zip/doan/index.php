<?php
    session_start();
    include_once('./ketnoi/ketnoi.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casio Shop - Website Bán Hàng Trực Tuyến</title>

<link rel="stylesheet" type="text/css" href="css/trangchu.css" />

<link rel="stylesheet" type="text/css" href="css/slideshow.css" />

<script type="text/javascript" src="js/jquery-1.2.6.min.js"></script>

<script type="text/javascript">




</script>

</head>
<body>

<!-- Wrapper -->
<div id="wrapper">
	<!-- Header -->
    <div id="header">
    	<div id="search-bar">
        	<!--Tìm kiếm-->
            <?php
                
            ?>
            <!--Giỏ hàng-->
            <?php
                include_once('Giohangcuaban.php');
            ?>
        </div>
       
        <div id="main-bar">
        	<div id="logo"><a href="index.php"><img src="anh/logo2.png" /></a></div>
            <div id="banner"></div>
           
        </div>
        <marquee  behavior="alternate" width="10%">>></marquee><a href="index.php?page_layout=sanphamgiamgia.php">Giam Gía Sốc</a><marquee behavior="alternate" width="10%"><< </marquee>
        <div id="navbar">
        	<ul>
            	<li id="menu-home"><a href="index.php">trang chủ</a></li>
                <li><a href="index.php?page_layout=gioithieu">giới thiệu</a></li>
                <li><a href="index.php?page_layout=dichvu">dịch vụ</a></li>
                <li><a href="index.php?page_layout=lienhe">liên hệ</a></li>
            </ul>
        </div>
    </div>
    <!-- End Header -->
    <!-- Body -->
    <div id="body">
    	<!-- Left Column -->
    	<div id="l-col">
        	<!--Tư vấn-->
            <?php
                include_once('./Sanpham/Danhsachtheoloaisp.php');
            ?>
            <!--Danh mục-->
            <?php
                include_once('./Sanpham/Danhsachnsx.php');
            ?>
            <!--Quảng cáo-->
            <?php
               
            ?>
            <!--Thống kê-->
            <?php
                include_once('./Thongke/thongke.php');
            ?>
            <!-- <div class="l-sidebar"></div> -->
        </div>
        <!-- End Left Column -->
        
        <!-- Right Column -->
        <div id="r-col">
        	<!--slideshow-->
            <style>
                 .mySlides {display:none;}
            </style>

            <div class="w3-content w3-section" style="max-width:720px">
                <img class="mySlides" src="anh/bn1.jpg" style="width:100%">
                <img class="mySlides" src="anh/bn3.jpg" style="width:100%">
                <img class="mySlides" src="anh/bn4.jpg" style="width:100%">
               
            </div>

            <script>
                var myIndex = 0;
                carousel();

                function carousel() {
                var i;
                var x = document.getElementsByClassName("mySlides");
                for (i = 0; i < x.length; i++) {
                    x[i].style.display = "none";  
                }
                myIndex++;
                if (myIndex > x.length) {myIndex = 1}    
                x[myIndex-1].style.display = "block";  
                setTimeout(carousel, 2000); 
                }
            </script>


            <div id="main">
            	<?php
                if(isset($_GET['page_layout'])){
                    switch($_GET['page_layout']){
                        case 'gioithieu':include_once('chucnang/menungang/gioithieu.php');break;
                        case 'dichvu':include_once('chucnang/menungang/dichvu.php');break;
                        case 'lienhe':include_once('lienhe.php');break;
                        case 'Chitietsp':include_once('./Sanpham/Chitietsp.php');break;
                        case 'sanphamtheonsx':include_once('./Sanpham/sanphamtheonsx.php');break;
                        case 'sanphamtheoloaisp':include_once('./Sanpham/sanphamtheoloaisp.php');break;
                        case 'danhsachtimkiem':include_once('chucnang/timkiem/danhsachtimkiem.php');break;
                        case 'giohang':include_once('Giohang.php');break;
                        case 'muahang':include_once('chucnang/giohang/muahang.php');break;
                        default:
                            include_once('./Sanpham/Sanphammoi.php');
                            include_once('./Sanpham/sanphamgshork.php');
                            include_once('./Sanpham/sanphamgiamgia.php');
                         
                    }
                }else{
                    include_once('./Sanpham/Sanphammoi.php');
                    include_once('./Sanpham/sanphamgshork.php');
                    include_once('./Sanpham/sanphamgiamgia.php');
                    
                }
                ?>
            </div>
        </div>
        <!-- End Right Column -->
    	    
   
   <img src="anh/dongho.png" />
  
    </div>
    <!-- End Body -->
    <!-- Footer -->
    <div id="footer">
    	<div id="footer-info">
        <h4>Trường Đại Học Công Nghệ TP.HCM </h4>
            <p><span>Nhóm 102:</span> Gồm 5 thành viên | <span>Đạt, Vũ, Quang, Khôi, Tài</span></p>
            <p><span>Đề Tài:</span> Xây dựng website kinh doanh đồng hồ | <span>Hotline</span> 099999999</p>
        </div>
    </div>
    <!-- End Footer -->
</div>
<!-- End Wrapper -->

</body>
</html>
