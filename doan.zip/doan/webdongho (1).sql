-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 05, 2022 lúc 01:57 AM
-- Phiên bản máy phục vụ: 10.4.22-MariaDB
-- Phiên bản PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `webdongho`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ctdonhang`
--

CREATE TABLE `ctdonhang` (
  `MaDonHang` int(11) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `DonGia` varchar(100) NOT NULL,
  `MaDongHo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `donhang`
--

CREATE TABLE `donhang` (
  `MaDonHang` int(11) NOT NULL,
  `ThanhToan` varchar(100) NOT NULL,
  `TinhTrangGiaoHang` varchar(100) NOT NULL,
  `NgayDat` date NOT NULL,
  `NgayGiao` date NOT NULL,
  `TongTien` int(11) NOT NULL,
  `MaKH` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khachhang`
--

CREATE TABLE `khachhang` (
  `MaKH` int(11) NOT NULL,
  `TenKH` varchar(100) NOT NULL,
  `TaiKhoan` varchar(50) NOT NULL,
  `MatKhau` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `DiaChi` varchar(200) NOT NULL,
  `SDT` varchar(20) NOT NULL,
  `NgaySinh` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaisp`
--

CREATE TABLE `loaisp` (
  `MaLoai` int(11) NOT NULL,
  `TenLoai` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `loaisp`
--

INSERT INTO `loaisp` (`MaLoai`, `TenLoai`) VALUES
(1, 'Đồng Hồ Đeo Tay'),
(2, 'Đồng Hồ Treo Tường'),
(3, 'Đồng Hồ Thông Minh');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nsx`
--

CREATE TABLE `nsx` (
  `MaNSX` int(11) NOT NULL,
  `TenNSX` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nsx`
--

INSERT INTO `nsx` (`MaNSX`, `TenNSX`) VALUES
(1, 'G-SHOCK'),
(2, 'CURNON'),
(3, 'DYOSS'),
(4, 'KASHI'),
(5, 'ETERNO');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `MaDongHo` int(11) NOT NULL,
  `TenDongHo` varchar(200) NOT NULL,
  `MaNSX` int(11) NOT NULL,
  `GiaBan` int(100) NOT NULL,
  `HinhAnh` varchar(100) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `MaLoai` int(11) NOT NULL,
  `TinhTrang` varchar(15) NOT NULL,
  `BaoHanh` varchar(20) NOT NULL,
  `KhuyenMai` int(20) NOT NULL,
  `MoTa` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`MaDongHo`, `TenDongHo`, `MaNSX`, `GiaBan`, `HinhAnh`, `SoLuong`, `MaLoai`, `TinhTrang`, `BaoHanh`, `KhuyenMai`, `MoTa`) VALUES
(1, 'Casio G-SHOCK GA-120-1ADR', 1, 365000, 'https://cdn.shopdongho.com/2018/09/casio-ga-120-1adr.jpg', 120, 1, 'Mới 100%', '6 Tháng', 1, ''),
(2, 'Casio G-SHOCK GA-113B', 1, 589000, 'https://cdn.shopdongho.com/2010/01/casio-g-shock-GA-113B-1ADR.jpg', 100, 1, '', '', 0, ''),
(3, 'STERLING ', 2, 256000, 'https://curnonwatch.com.vn/wp-content/uploads/2017/12/IMG_5250_1_2048x.jpg', 50, 1, '', '', 0, ''),
(4, 'Casio G-SHOCK GA-120BB', 1, 378000, 'https://cdn.shopdongho.com/2010/01/casio-g-shock-GA-120BB-1AHDR.jpg', 50, 1, '', '', 0, ''),
(5, 'Đồng hồ Nam Q&Q S306J301Y', 3, 693000, 'https://cdn.tgdd.vn/Products/Images/7264/216115/q-q-s306j301y-nam-2-org.jpg', 50, 1, '', '', 0, ''),
(6, 'Đồng hồ Nam Q&Q S284J101Y', 4, 693000, 'https://cdn.tgdd.vn/Products/Images/7264/245134/q-q-s284j101y-nam-2-org.jpg', 50, 1, '', '', 0, ''),
(7, 'Đồng hồ Nữ ELIO EL085-02', 2, 792000, 'https://cdn.tgdd.vn/Products/Images/7264/249250/elio-el085-02-nu-2.jpg', 0, 1, 'Mới 100%', '12 Tháng', 5, '- Mang nét thanh lịch, tinh tế, chiếc đồng hồ này đến từ hãng đồng hồ Elio chất lượng của Việt Nam - thương hiệu độc quyền của Thế Giới Di Động\r\n\r\n- Chiếc đồng hồ nữ này có bộ máy của Nhật Bản, cho độ bền cao, hoạt động ổn định và chính xác trong thời gian dài\r\n\r\n- Đồng hồ có kích thước mặt 21 x 22 mm, độ rộng dây 10 mm\r\n\r\n- Dây da tổng hợp êm ái, nhẹ nhàng, ôm sát cổ tay, khung viền hợp kim có độ bền cao, chống ăn mòn, bảo vệ tốt phần lõi bên trong\r\n\r\n- Chỉ số chống nước 3 ATM: Đồng hồ vẫn an toàn khi bạn đeo đi mưa, rửa tay, không mang khi tắm, bơi, lặn');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `ctdonhang`
--
ALTER TABLE `ctdonhang`
  ADD PRIMARY KEY (`MaDonHang`),
  ADD KEY `MaSP` (`MaDongHo`);

--
-- Chỉ mục cho bảng `donhang`
--
ALTER TABLE `donhang`
  ADD PRIMARY KEY (`MaDonHang`),
  ADD KEY `MaKH` (`MaKH`);

--
-- Chỉ mục cho bảng `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`MaKH`);

--
-- Chỉ mục cho bảng `loaisp`
--
ALTER TABLE `loaisp`
  ADD PRIMARY KEY (`MaLoai`);

--
-- Chỉ mục cho bảng `nsx`
--
ALTER TABLE `nsx`
  ADD PRIMARY KEY (`MaNSX`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`MaDongHo`),
  ADD KEY `MaNSX` (`MaNSX`),
  ADD KEY `MaLoai` (`MaLoai`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `ctdonhang`
--
ALTER TABLE `ctdonhang`
  MODIFY `MaDonHang` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `donhang`
--
ALTER TABLE `donhang`
  MODIFY `MaDonHang` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `khachhang`
--
ALTER TABLE `khachhang`
  MODIFY `MaKH` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `loaisp`
--
ALTER TABLE `loaisp`
  MODIFY `MaLoai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `nsx`
--
ALTER TABLE `nsx`
  MODIFY `MaNSX` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `MaDongHo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `ctdonhang`
--
ALTER TABLE `ctdonhang`
  ADD CONSTRAINT `ctdonhang_ibfk_1` FOREIGN KEY (`MaDongHo`) REFERENCES `sanpham` (`MaDongHo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `donhang`
--
ALTER TABLE `donhang`
  ADD CONSTRAINT `donhang_ibfk_1` FOREIGN KEY (`MaKH`) REFERENCES `khachhang` (`MaKH`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `donhang_ibfk_2` FOREIGN KEY (`MaDonHang`) REFERENCES `ctdonhang` (`MaDonHang`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`MaNSX`) REFERENCES `nsx` (`MaNSX`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sanpham_ibfk_2` FOREIGN KEY (`MaLoai`) REFERENCES `loaisp` (`MaLoai`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
