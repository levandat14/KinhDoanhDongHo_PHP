<link rel="stylesheet" type="text/css" href="css/chitietsp.css" />
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="style.css">
<div class="prd-comment">
    <h3>Thông Tin Liên Hệ</h3>
    <p><span class="glyphicon glyphicon-user"></span>Lê Văn Đạt </p>
    <li><p><span class="glyphicon glyphicon-user"></span>Trần Nhật Quang </p>
                <p><span class="glyphicon glyphicon-user"></span>Nguyễn Tiến Vũ </p>
                <p><span class="glyphicon glyphicon-user"></span>Nguyễn Trương Tấn Khôi</p>
                <p><span class="glyphicon glyphicon-user"></span>Trần Tấn Tài </p></li>
                
             <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
             <span>Phường 24
               Quận Bình Thạnh,<br />
               Thành Phố Hồ Chí Minh
             </span>
          
           <li>
             <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
             <span>levandat1405@gmail.com</span>
           </li>
          <li>
             <span><i class="fa fa-phone-square" aria-hidden="true"></i></span>
             <span>012-345-6789</span>
           </li>
           
               
    </div>
<div class="prd-details">
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMobile-Shop-104937364400027&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
   
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.1251208107665!2d106.71229765031123!3d10.801727892266626!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317528a459cb43ab%3A0x6c3d29d370b52a7e!2zVHLGsOG7nW5nIMSQ4bqhaSBo4buNYyBDw7RuZyBuZ2jhu4cgVFAuSENN!5e0!3m2!1svi!2s!4v1627361789782!5m2!1svi!2s" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        
        </div>

    
    

