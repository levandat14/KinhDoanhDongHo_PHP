<?php
        require_once("./ketnoi/ketnoi.php");
        $MaNSX = $_GET['MaNSX'];
        $sql = "SELECT * FROM sanpham WHERE MaNSX = $MaNSX ";
        $query = mysqli_query($conn , $sql);
      
    ?>
    <?php
    $MaNSX = $_GET['MaNSX'];
    $sqlnsx="SELECT * FROM nsx  WHERE MaNSX = $MaNSX ";
    $querynsx=mysqli_query($conn, $sqlnsx);
    $rownsx=mysqli_fetch_array($querynsx);
    ?>
   
    <div class="prd-block">
    <h2><form method="post"  >
        <?php
      echo $rownsx['TenNSX'];
      ?> 
      <style>
          .lesapxep{
              margin-left: 450px;
          }
      </style>
       <select class="form-control lesapxep" name="sapxep">
                            <option value="" selected>------Xếp Theo-----</option>
                            <option value="1">Gía Cao Tới Thấp</option>
                            <option value="2">Gía Thấp Tới Cao</option>
                            <input class="btn btn-success" type="submit" name="btnsubmit" value="Lọc" />
                         
                            
        </select></form>
    </h2>
    <!---cao tới thấp---->
    <?php
         
        if(isset($_POST["btnsubmit"])){ 
                $sx=$_POST['sapxep'];                 
    ?>
    <?php
        if($sx==1){
            
            $MaNSX = $_GET['MaNSX'];
            $sql = "SELECT * FROM sanpham WHERE MaNSX = $MaNSX order by GiaBan desc ";
            $query = mysqli_query($conn , $sql);  
    ?>
    <div class="pr-list">
      
      <?php
        
          while($row=mysqli_fetch_array($query)){
      ?>
         
          <div class="prd-item">
         <a href="index.php?page_layout=Chitietsp&MaDongHo=<?php echo $row['MaDongHo'] ?>">  <img src="<?php echo  $row['HinhAnh'];?>" class="img-responsive" style="width: 100%" alt="Image"></a>
              <h3><a href="#"><?php echo $row['TenDongHo'] ?></a></h3>
             
              <p class="price"><span>Giá: <?php $format_number_1 = number_format($row['GiaBan']); echo $format_number_1 ?> VNĐ</span></p>
          </div>
      <?php
          }
      ?>
      </div>
 

    <?php 
    }     
     ?>
     <!----thap toi cao-------->
     <?php
     
         if($sx==2){

            
             $MaNSX = $_GET['MaNSX'];
             $sql = "SELECT * FROM sanpham WHERE MaNSX = $MaNSX order by GiaBan ";
             $query = mysqli_query($conn , $sql);    
            
     ?>
     <div class="pr-list">
       
       <?php
         
           while($row=mysqli_fetch_array($query)){
       ?>
          
           <div class="prd-item">
          <a href="index.php?page_layout=Chitietsp&MaDongHo=<?php echo $row['MaDongHo'] ?>">  <img src="<?php echo  $row['HinhAnh'];?>" class="img-responsive" style="width: 100%" alt="Image"></a>
               <h3><a href="#"><?php echo $row['TenDongHo'] ?></a></h3>
              
               <p class="price"><span>Giá: <?php $format_number_1 = number_format($row['GiaBan']); echo $format_number_1 ?> VNĐ</span></p>
           </div>
       <?php
           }
       ?>
       
           <div class="clear"></div>
       </div>
  
 
     <?php 
 }
 }    
    
      ?>
    <div class="pr-list">
      <!---mặc định --->
    <?php
      
        while($row=mysqli_fetch_array($query)){
    ?>
       
        <div class="prd-item">
       <a href="index.php?page_layout=Chitietsp&MaDongHo=<?php echo $row['MaDongHo'] ?>">  <img src="<?php echo  $row['HinhAnh'];?>" class="img-responsive" style="width: 100%" alt="Image"></a>
            <h3><a href="#"><?php echo $row['TenDongHo'] ?></a></h3>
           
            <p class="price"><span>Giá: <?php $format_number_1 = number_format($row['GiaBan']); echo $format_number_1 ?> VNĐ</span></p>
        </div>
    <?php

        }
    ?>
    
        <div class="clear"></div>
    </div>
</div>